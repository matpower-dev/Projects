#After installation, do below to run:
#pizza_test.sh
python -m pizzapackage.pizza_test
